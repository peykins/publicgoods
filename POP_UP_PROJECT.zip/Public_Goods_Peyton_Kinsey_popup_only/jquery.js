$(document).ready(function() {
        $('#popup').delay(5000).animate({"top":"50%","marginTop":"-200px"},500);

  $("#btnClose").click(function (e)
	{
		HideDialog();
		e.preventDefault();
	});
	$("#claim").click(function (e)
	{
		HideDialog();
		e.preventDefault();
	});
    });

function HideDialog()
{
	$("#popup").animate({"top":"50%","marginTop":"700px"},300);
}
