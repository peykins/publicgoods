$(document).ready(function ()
{
	$("#delayedPopup").delay(5000).fadeIn(400);

	$("#btnClose").click(function (e)
	{
		HideDialog();
		e.preventDefault();
	});
	$("#claim").click(function (e)
	{
		HideDialog();
		e.preventDefault();
	});
});


function HideDialog()
{
	$("#delayedPopup").fadeOut(300);
}
